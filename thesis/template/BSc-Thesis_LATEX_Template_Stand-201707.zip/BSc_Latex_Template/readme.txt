Change history:
Oct 5, 2015 -- created by Daniela Ramsauer and Phillip Chlap
Oct 6, 2015 -- modified (adding small caps & readme file) by Torsten Moeller
  * added a bib file
  * added small caps font for heading
  * created a readme file

how to use:

1. on a unix prompt:
  > pdflatex BSc_Latex_Template
  > bibtex BSc_Latex_Template
  > pdflatex BSc_Latex_Template
  > pdflatex BSc_Latex_Template
